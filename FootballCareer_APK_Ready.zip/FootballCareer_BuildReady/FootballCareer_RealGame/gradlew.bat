@echo off
setlocal
set "GRADLE_VERSION=8.9"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "CACHE=%GRADLE_USER_HOME%\wrapper\dists\gradle-%GRADLE_VERSION%-bin"
set "DIST=%CACHE%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
if exist "%DIST%" goto run
if not exist "%CACHE%" mkdir "%CACHE%"
set "ZIP=%CACHE%\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%ZIP%" (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP%' '%CACHE%'"
if errorlevel 1 exit /b 1
:run
call "%DIST%" %*
endlocal
