# Football Career — Android build package

Dies ist ein natives Android-Projekt. Es verwendet **keine Google-Play-Services** und braucht für die App selbst keine Google-Dienste.

## Zielgerät
- Android 8.0+ (API 26+)
- Portrait
- Native Java/Android UI

## Build
AGP 8.7.3 / Gradle 8.9 / compileSdk 35 / targetSdk 35 / Java 17.

### Direkt mit Android Studio
Ordner `FootballCareer` öffnen und `assembleDebug` ausführen.

### Automatischer APK-Build ohne lokale Android-Installation
Die Datei `.github/workflows/build-apk.yml` baut auf einem GitHub Actions Runner eine echte, installierbare Debug-APK und stellt sie als Artifact bereit.

APK-Ausgabe:
`app/build/outputs/apk/debug/app-debug.apk`

## Wichtig
Diese Version ist ein echter, kompilierbarer Spielkern, aber noch nicht die komplette Endfassung des zuvor beschriebenen Football-Career-Spiels. Nicht implementierte Großsysteme werden weiter ausgebaut statt als fertige Funktionen vorgetäuscht.
