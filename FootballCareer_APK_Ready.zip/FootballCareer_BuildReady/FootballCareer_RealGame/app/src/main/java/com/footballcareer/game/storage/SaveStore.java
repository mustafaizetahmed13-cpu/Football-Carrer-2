package com.footballcareer.game.storage;
import android.content.*; import com.footballcareer.game.data.Models.GameState; import java.io.*;
public class SaveStore { private static final String F="career.save"; public static void save(Context c,GameState s){try(ObjectOutputStream o=new ObjectOutputStream(c.openFileOutput(F,Context.MODE_PRIVATE))){o.writeObject(s);}catch(Exception ignored){}} public static GameState load(Context c){try(ObjectInputStream i=new ObjectInputStream(c.openFileInput(F))){return (GameState)i.readObject();}catch(Exception e){return null;}} }
