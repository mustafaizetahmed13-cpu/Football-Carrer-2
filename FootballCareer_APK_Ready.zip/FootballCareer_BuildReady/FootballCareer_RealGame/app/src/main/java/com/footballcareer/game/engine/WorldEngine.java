package com.footballcareer.game.engine;
import com.footballcareer.game.data.Models.*; import java.util.*;

public class WorldEngine {
  private final Random r=new Random(); public final GameState s;
  public WorldEngine(GameState state){s=state;}
  public void nextDay(){s.day++; if(s.day>30){s.day=1;s.month++;} if(s.month>12){s.month=1;s.year++; for(League l:s.leagues.values()) l.pts.replaceAll((k,v)->0);} simulateWorld();}
  private void simulateWorld(){ for(Player p:s.players.values()){ if(!p.id.equals(s.activePlayerId)){p.form=Math.max(35,Math.min(95,p.form+r.nextInt(7)-3)); if(r.nextInt(100)<2 && p.fitness>20)p.fitness-=r.nextInt(20); else p.fitness=Math.min(98,p.fitness+2); } } }
  public Match playMatch(String playerClub){ Club c=s.clubs.get(playerClub); if(c==null)return null; List<Club> all=new ArrayList<>(s.clubs.values()); if(all.size()<2)return null; Club opp=all.get(r.nextInt(all.size())); while(opp.id.equals(playerClub))opp=all.get(r.nextInt(all.size())); Match m=new Match(c.id,opp.id); int h=0,a=0; for(int i=0;i<3;i++){if(r.nextInt(100)<35+c.reputation/10)h++;if(r.nextInt(100)<30+opp.reputation/10)a++;}m.hg=h;m.ag=a; if(s.leagues.containsKey(c.leagueId)){League l=s.leagues.get(c.leagueId);l.pts.put(c.id,l.pts.getOrDefault(c.id,0)+(h>a?3:h==a?1:0));l.pts.put(opp.id,l.pts.getOrDefault(opp.id,0)+(a>h?3:a==h?1:0));} return m; }
  public void train(Player p){p.fitness=Math.max(30,p.fitness-8); p.form=Math.min(95,p.form+4); if(p.ovr<p.potential && r.nextInt(100)<35){p.ovr++; p.a.put("development",p.a.getOrDefault("development",0)+1);} }
}
