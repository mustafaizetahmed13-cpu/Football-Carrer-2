package com.footballcareer.game.data;

import java.io.Serializable;
import java.util.*;

public final class Models {
  public static class Player implements Serializable {
    public String id,name,nationality,position,clubId; public int age,ovr,potential,fitness=90,morale=70,form=70; public int goals,assists,apps,minutes;
    public Map<String,Integer> a=new HashMap<>();
    public Player(String id,String name,int age,String pos,int ovr,int potential,String club){this.id=id;this.name=name;this.age=age;this.position=pos;this.ovr=ovr;this.potential=potential;this.clubId=club;}
  }
  public static class Club implements Serializable { public String id,name,leagueId,country,stadium; public int reputation,finance=1000000; public List<String> squad=new ArrayList<>(); public Club(String i,String n,String l,String c,String s,int r){id=i;name=n;leagueId=l;country=c;stadium=s;reputation=r;} }
  public static class League implements Serializable { public String id,name,country; public int tier; public List<String> clubs=new ArrayList<>(); public Map<String,Integer> pts=new HashMap<>(); public League(String i,String n,String c,int t){id=i;name=n;country=c;tier=t;} }
  public static class Match implements Serializable { public String home,away; public int hg,ag; public Match(String h,String a){home=h;away=a;} }
  public static class GameState implements Serializable { public int day=1,month=7,year=2035; public String activePlayerId; public Map<String,Player> players=new HashMap<>(); public Map<String,Club> clubs=new HashMap<>(); public Map<String,League> leagues=new HashMap<>(); public List<String> news=new ArrayList<>(); public int balance=0; }
}
