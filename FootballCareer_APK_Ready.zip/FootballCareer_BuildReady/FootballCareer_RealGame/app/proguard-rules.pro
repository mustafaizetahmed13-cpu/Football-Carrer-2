# Football Career - release rules
